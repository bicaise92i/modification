<?php
/**
 * Created by PhpStorm.
 * User: phuongth
 * Date: 5/18/2016
 * Time: 10:27 AM
 */
if (!defined('ABSPATH')) {
    die('-1');
}
class WPBakeryShortCode_G5Plus_Button extends G5Plus_ShortCode {

}