<div class="gsf-meta-box-wrap">
	<?php gsf_get_template('templates/meta-box-section', array('list_section' => $list_section)) ?>
	<div class="gsf-fields">
		<div class="gsf-fields-wrapper">
