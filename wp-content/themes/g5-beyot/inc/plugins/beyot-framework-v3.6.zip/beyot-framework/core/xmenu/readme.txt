FILTERS IN XMENU
----------------
1. xmenu_filter_before
2. xmenu_filter_after
3. xmenu_nav_filter_before
4. xmenu_nav_filter_after
4. xmenu_primary_filter_before (only primary location)